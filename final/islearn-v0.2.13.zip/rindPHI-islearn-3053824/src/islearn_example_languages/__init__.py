from islearn_example_languages.languages import *
